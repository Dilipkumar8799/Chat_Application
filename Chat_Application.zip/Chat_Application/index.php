<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Application</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

</head>
<body>
    <div class="wrapper">
        <section class="form">
            <header>Chat Application</header>
            <form action="#" enctype="multipart/form-data" autocomplete="off">
                <div class="error-txt"></div>
                <div class="name-details">
                    <div class="field">
                    <label>First name</label>
                        <input type="text" name="fname" placeholder="First name" required>
                    </div>
                    <div class="field">
                        <label>Last name</label> 
                        <input type="text" name="lname" placeholder="Last name" required>
                    </div>
                </div>
                    <div class="field">
                        <label>Email Address</label>
                        <input type="text" name="email" placeholder="Enter your email" required>
                    </div>
                    <div class="field">
                        <label>Password</label>
                        <input type="password" name="password" placeholder="Enter new password" required>
                        <i class="fa fa-eye"></i>
                    </div>
                    <div class="image">
                        <label>Select Image</label>
                        <input type="file" name="image">
                    </div>
                    <div class="button">
                        <input type="submit" value="Continue to Chat">
                    </div>
                </form>
            <div class="link">Already Signed up? <a href="login.php">Login now</a></div>
        </section>
    </div>

    <script src="JavaScript/password-hide.js"></script>
    <script src="JavaScript/signup.js"></script>
</body>
</html>