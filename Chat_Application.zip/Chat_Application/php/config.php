<?php 
   $conn = mysqli_connect("localhost", "root", "", "ChatApp");

   if (!$conn) {
       die("Connection failed: " . mysqli_connect_error());
   }
   
?>