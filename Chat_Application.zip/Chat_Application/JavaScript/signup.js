let forms = document.querySelector(".form form"),
continueBtn = forms.querySelector(".button input"),
errorText = forms.querySelector(".error-txt");

forms.onsubmit = (e) =>{
    e.preventDefault(); //preventing form from submitting
}

continueBtn.onclick = () =>{
    //let's start ajax
    let xhr = new XMLHttpRequest(); //Creating xml object
    xhr.open("POST","php/signup.php",true);
    xhr.onload = () =>{
        if(xhr.readyState === XMLHttpRequest.DONE){
            if(xhr.status === 200){
                let data = xhr.response;
                if(data == "success"){
                    location.href = "user.php";
                }
                else{
                    errorText.textContent = data;
                    errorText.style.display = "block";
                }
            }
        }
    }
    //we have to send the form data through ajax to php
    let formData = new FormData(forms); //creating new formData object
    xhr.send(formData); //sending the form data to php
    
}   