const ps = document.querySelector(".form input[type='password']"),
toggleBtn = document.querySelector(".form .field i");

toggleBtn.onclick = () =>{
    if(ps.type == "password"){
        ps.type = "text";
        toggleBtn.classList.add("active");
    }else{
        ps.type = "password";
        toggleBtn.classList.remove("active");
    }
}