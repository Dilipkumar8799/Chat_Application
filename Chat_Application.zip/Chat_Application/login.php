<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Application</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

</head>
<?php 
  session_start();
  if(isset($_SESSION['unique_id'])){
    header("location: user.php");
  }
?>
<body>
    <div class="wrapper">
        <section class="form">
            <header>Chat Application</header>
            <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
                <div class="error-txt"></div>
                    <div class="field">
                        <label>Email Address</label>
                        <input type="text" placeholder="Enter your email" required>
                    </div>
                    <div class="field">
                        <label>Password</label>
                        <input type="password" placeholder="Enter your password" required>
                        <i class="fa fa-eye"></i>
                    </div>
                    <div class="button">
                        <input type="submit" value="Continue to Chat">
                    </div>
                </form>
            <div class="link">Not yet Signed up? <a href="index.php">Signup now</a></div>
        </section>
    </div>
    <script src="JavaScript/password-hide.js"></script>
    <script src="JavaScript/login.js"></script>
</body>
</html>